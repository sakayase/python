# exo 1.1
# Affichez le message "programme démarré" en utilisant des doubles quotes

# réponse 1.1
print("programme démarré")

# exo 1.2
# Affichez le message "programme terminé" en utilisant des simples quotes

# réponse 1.2
print('programme terminé')

