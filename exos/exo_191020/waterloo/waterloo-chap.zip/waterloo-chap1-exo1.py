# What is the value of x after these commands execute?

# x = 10
# x = x + x
# x = x - 5 

# Reponse : 15

# people = defined ?
import random


people = random.randint(40,100)
heads = 1 * people
shoulders = 2 * people
knees = people * 2
toes = 10 * people

print(people)