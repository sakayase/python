print("Hello")
username = "Joe" 
print(username)
